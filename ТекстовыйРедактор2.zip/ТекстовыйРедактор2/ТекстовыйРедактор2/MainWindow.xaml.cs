﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ТекстовыйРедактор2
{
    public partial class MainWindow : Window
    {
        private string currentFileName;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TextEditor.Document.Blocks.Clear();
            currentFileName = string.Empty;

            string dataDirectory = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "data");
            if (!Directory.Exists(dataDirectory))
            {
                Directory.CreateDirectory(dataDirectory);
            }

           
            cmbFontFamily.ItemsSource = Fonts.SystemFontFamilies.OrderBy(f => f.Source);
            cmbFontSize.ItemsSource = new List<double>() { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
        }

        private void OpenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Rich Text Format (*.rtf)|*.rtf|Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            openFileDialog.InitialDirectory = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "data");

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    TextRange range = new TextRange(TextEditor.Document.ContentStart, TextEditor.Document.ContentEnd);
                    using (FileStream fs = new FileStream(openFileDialog.FileName, FileMode.Open))
                    {
                        string fileExtension = System.IO.Path.GetExtension(openFileDialog.FileName).ToLower();
                        string dataFormat = (fileExtension == ".rtf") ? DataFormats.Rtf : DataFormats.Text;

                        range.Load(fs, dataFormat);
                    }

                    currentFileName = openFileDialog.FileName;
                    this.Title = $"Текстовый редактор - {System.IO.Path.GetFileName(currentFileName)}";
                }
                catch (FileNotFoundException ex)
                {
                    MessageBox.Show($"{ex.Message}\nНет такого файла", "Ошибка",
                                        MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка",
                                        MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
        }

        private void SaveAsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Rich Text Format (*.rtf)|*.rtf|Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";

            if (!string.IsNullOrEmpty(currentFileName))
            {
                saveFileDialog.FileName = System.IO.Path.GetFileName(currentFileName);
                saveFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(currentFileName);
            }
            else
            {
                saveFileDialog.InitialDirectory = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "data");
            }

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    TextRange range = new TextRange(TextEditor.Document.ContentStart, TextEditor.Document.ContentEnd);
                    using (FileStream fs = new FileStream(saveFileDialog.FileName, FileMode.Create))
                    {
                        string fileExtension = System.IO.Path.GetExtension(saveFileDialog.FileName).ToLower();
                        string dataFormat = (fileExtension == ".txt") ? DataFormats.Text : DataFormats.Rtf;

                        range.Save(fs, dataFormat);
                    }

                    currentFileName = saveFileDialog.FileName;
                    this.Title = $"Текстовый редактор - {System.IO.Path.GetFileName(currentFileName)}";

                    MessageBox.Show("Файл успешно сохранен!", "Сохранение",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка",
                                        MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
        }

        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TextEditor_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

      

        private void cmbFontFamily_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbFontFamily.SelectedItem != null && !TextEditor.Selection.IsEmpty)
            {
                TextEditor.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, cmbFontFamily.SelectedItem);
            }
        }

        private void cmbFontSize_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbFontSize.Text) && !TextEditor.Selection.IsEmpty)
            {
                if (double.TryParse(cmbFontSize.Text, out double fontSize))
                {
                    TextEditor.Selection.ApplyPropertyValue(TextElement.FontSizeProperty, fontSize);
                }
            }
        }

        private void BoldButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TextEditor.Selection.IsEmpty)
            {
                var currentWeight = TextEditor.Selection.GetPropertyValue(TextElement.FontWeightProperty);
                FontWeight newWeight = (currentWeight != DependencyProperty.UnsetValue && (FontWeight)currentWeight == FontWeights.Bold)
                    ? FontWeights.Normal
                    : FontWeights.Bold;
                TextEditor.Selection.ApplyPropertyValue(TextElement.FontWeightProperty, newWeight);
            }
        }

        private void ItalicButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TextEditor.Selection.IsEmpty)
            {
                var currentStyle = TextEditor.Selection.GetPropertyValue(TextElement.FontStyleProperty);
                FontStyle newStyle = (currentStyle != DependencyProperty.UnsetValue && (FontStyle)currentStyle == FontStyles.Italic)
                    ? FontStyles.Normal
                    : FontStyles.Italic;
                TextEditor.Selection.ApplyPropertyValue(TextElement.FontStyleProperty, newStyle);
            }
        }

        private void UnderlineButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TextEditor.Selection.IsEmpty)
            {
                var currentDecoration = TextEditor.Selection.GetPropertyValue(Inline.TextDecorationsProperty);

                bool isUnderlined = (currentDecoration != DependencyProperty.UnsetValue) && TextDecorations.Underline.Equals(currentDecoration);

                TextDecorationCollection newDecoration = isUnderlined
                    ? null 
                    : TextDecorations.Underline; 

                TextEditor.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty, newDecoration);
            }
        }

       
        private void TextEditor_SelectionChanged(object sender, RoutedEventArgs e)
        {
           
            var weight = TextEditor.Selection.GetPropertyValue(TextElement.FontWeightProperty);
            BoldButton.IsChecked = (weight != DependencyProperty.UnsetValue) && (FontWeight)weight == FontWeights.Bold;

            var style = TextEditor.Selection.GetPropertyValue(TextElement.FontStyleProperty);
            ItalicButton.IsChecked = (style != DependencyProperty.UnsetValue) && (FontStyle)style == FontStyles.Italic;

            
            var decoration = TextEditor.Selection.GetPropertyValue(Inline.TextDecorationsProperty);
           
            UnderlineButton.IsChecked = (decoration != DependencyProperty.UnsetValue) && TextDecorations.Underline.Equals(decoration);

          
            var fontFamily = TextEditor.Selection.GetPropertyValue(TextElement.FontFamilyProperty);
            if (fontFamily != DependencyProperty.UnsetValue)
                cmbFontFamily.SelectedItem = fontFamily;

            var fontSize = TextEditor.Selection.GetPropertyValue(TextElement.FontSizeProperty);
            if (fontSize != DependencyProperty.UnsetValue)
                cmbFontSize.Text = fontSize.ToString();
        }
    }
}