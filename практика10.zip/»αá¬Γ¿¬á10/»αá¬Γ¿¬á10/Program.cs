﻿using System;



// Принцип 1: Абстракция
public abstract class Shape
{
    public abstract double CalculateArea();
    public virtual void Display()
    {
        Console.WriteLine($"Это геометрическая фигура");
    }
}

// Принцип 2: Наследование
public class Circle : Shape
{
    public double Radius { get; set; }

    public Circle(double radius)
    {
        Radius = radius;
    }

    public override double CalculateArea()
    {
        return Math.PI * Radius * Radius;
    }

    public override void Display()
    {
        Console.WriteLine($"Круг с радиусом {Radius}");
    }
}

public class Rectangle : Shape
{
    public double Width { get; set; }
    public double Height { get; set; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public override double CalculateArea()
    {
        return Width * Height;
    }

    public override void Display()
    {
        Console.WriteLine($"Прямоугольник {Width}x{Height}");
    }
}

// Принцип 3: Инкапсуляция
public class BankAccount
{
    private double _balance;
    private string _accountNumber;

    public BankAccount(string accountNumber, double initialBalance)
    {
        _accountNumber = accountNumber;
        _balance = initialBalance;
    }

    public string AccountNumber
    {
        get { return _accountNumber; }
    }

    public double Balance
    {
        get { return _balance; }
    }

    public void Deposit(double amount)
    {
        if (amount > 0)
        {
            _balance += amount;
            Console.WriteLine($"Внесено: {amount}. Новый баланс: {_balance}");
        }
    }

    public bool Withdraw(double amount)
    {
        if (amount > 0 && amount <= _balance)
        {
            _balance -= amount;
            Console.WriteLine($"Снято: {amount}. Новый баланс: {_balance}");
            return true;
        }
        Console.WriteLine("Недостаточно средств");
        return false;
    }
}

// Принцип 4: Полиморфизм
public interface IAnimal
{
    void MakeSound();
}

public class Dog : IAnimal
{
    public void MakeSound()
    {
        Console.WriteLine("Гав-гав!");
    }
}

public class Cat : IAnimal
{
    public void MakeSound()
    {
        Console.WriteLine("Мяу!");
    }
}

public class ComplexNumber
{
    public double Real { get; set; }
    public double Imaginary { get; set; }

    public ComplexNumber(double real, double imaginary)
    {
        Real = real;
        Imaginary = imaginary;
    }

    // Перегрузка методов
    public void Display()
    {
        Console.WriteLine($"{Real} + {Imaginary}i");
    }

    public void Display(string format)
    {
        Console.WriteLine($"Комплексное число: {Real} + {Imaginary}i");
    }

    // Перегрузка операторов
    public static ComplexNumber operator +(ComplexNumber a, ComplexNumber b)
    {
        return new ComplexNumber(a.Real + b.Real, a.Imaginary + b.Imaginary);
    }

    public static ComplexNumber operator -(ComplexNumber a, ComplexNumber b)
    {
        return new ComplexNumber(a.Real - b.Real, a.Imaginary - b.Imaginary);
    }

    public static bool operator ==(ComplexNumber a, ComplexNumber b)
    {
        return a.Real == b.Real && a.Imaginary == b.Imaginary;
    }

    public static bool operator !=(ComplexNumber a, ComplexNumber b)
    {
        return !(a == b);
    }

    // Преобразование типов
    public static implicit operator ComplexNumber(double real)
    {
        return new ComplexNumber(real, 0);
    }

    public static explicit operator double(ComplexNumber complex)
    {
        return complex.Real;
    }

    public override string ToString()
    {
        return $"{Real} + {Imaginary}i";
    }

    public override bool Equals(object obj)
    {
        if (obj is ComplexNumber other)
            return this == other;
        return false;
    }

    public override int GetHashCode()
    {
        return Real.GetHashCode() ^ Imaginary.GetHashCode();
    }
}


public class QuadraticEquationSolver
{
    public static void SolveQuadraticEquation()
    {
        Console.WriteLine("Решение квадратного уравнения ax² + bx + c = 0");

        Console.Write("Введите a: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите b: ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите c: ");
        double c = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine($"Уравнение: {a}x² + {b}x + {c} = 0");


        if (a == 0)
        {
            if (b == 0)
            {
                if (c == 0)
                {
                    Console.WriteLine("x - любое число");
                }
                else
                {
                    Console.WriteLine("Нет решения");
                }
            }
            else
            {
                double x1 = -c / b;
                Console.WriteLine($"x1 = {x1}");
            }
        }
        else
        {
            
            double D = b * b - a * a * c; 

            if (D > 0)
            {
                double sqrtD = Math.Sqrt(D);
                double x1 = (b + sqrtD) / (2 * a);
                double x2 = (b - sqrtD) / (2 * a);
                Console.WriteLine($"x1 = {x1}, x2 = {x2}");
            }
            else if (D == 0)
            {
                double x1 = -b / (2 * a);
                Console.WriteLine($"x1 = {x1}");
            }
            else
            {
                Console.WriteLine("Нет действительных решений");
            }
        }
    }
}


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ПРИНЦИПЫ ООП");

       
        Console.WriteLine("\n1. Принципы ООП:");

       
        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(4, 6);

        circle.Display();
        Console.WriteLine($"Площадь: {circle.CalculateArea():F2}");

        rectangle.Display();
        Console.WriteLine($"Площадь: {rectangle.CalculateArea():F2}");

      
        Console.WriteLine("\nИнкапсуляция:");
        BankAccount account = new BankAccount("123456", 1000);
        account.Deposit(500);
        account.Withdraw(200);
        Console.WriteLine($"Баланс счета {account.AccountNumber}: {account.Balance}");

   
        Console.WriteLine("\nПолиморфизм:");
        IAnimal[] animals = { new Dog(), new Cat() };
        foreach (var animal in animals)
        {
            animal.MakeSound();
        }

       
        Console.WriteLine("\n\n2. Перегрузка методов и операторов:");

        ComplexNumber num1 = new ComplexNumber(3, 4);
        ComplexNumber num2 = new ComplexNumber(1, 2);

        Console.Write("num1: ");
        num1.Display();

        Console.Write("num2: ");
        num2.Display("форматированный");

        ComplexNumber sum = num1 + num2;
        Console.Write("Сумма: ");
        sum.Display();

        ComplexNumber diff = num1 - num2;
        Console.Write("Разность: ");
        diff.Display();

       
        ComplexNumber num3 = 5.0; 
        double realPart = (double)num1; 

        Console.WriteLine($"Неявное преобразование: {num3}");
        Console.WriteLine($"Явное преобразование: {realPart}");

        
        Console.WriteLine("\n\n3. Решение квадратного уравнения:");
        QuadraticEquationSolver.SolveQuadraticEquation();

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }
}