﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ZharPtitsaRestaurant
{
   
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }

        public User(int id, string name, string phone)
        {
            Id = id;
            Name = name;
            Phone = phone;
        }

        public virtual void Register()
        {
            Console.WriteLine($"Пользователь {Name} успешно зарегистрирован.");
        }

        public virtual void Login()
        {
            Console.WriteLine($"Пользователь {Name} вошел в систему.");
        }

        public void DisplayUserInfo()
        {
            Console.WriteLine($"ID: {Id}, Имя: {Name}, Телефон: {Phone}");
        }
    }

   
    public class Client : User
    {
        public int CardNumber { get; set; }
        public int BonusPoints { get; set; }

        public Client(int id, string name, string phone, int cardNumber)
            : base(id, name, phone)
        {
            CardNumber = cardNumber;
            BonusPoints = 0;
        }

        public Order CreateOrder(int orderNumber)
        {
            Console.WriteLine($"Клиент {Name} создал новый заказ №{orderNumber}");
            return new Order(orderNumber, this.Id);
        }

        public void PayOrder(decimal amount)
        {
            Console.WriteLine($"Заказ оплачен на сумму {amount} руб.");
            AccrueBonuses(amount);
        }

        private void AccrueBonuses(decimal amount)
        {
            int bonuses = (int)(amount / 10); 
            BonusPoints += bonuses;
            Console.WriteLine($"Начислено бонусов: {bonuses}. Всего бонусов: {BonusPoints}");
        }

        public void UseBonuses(int points)
        {
            if (points <= BonusPoints)
            {
                BonusPoints -= points;
                Console.WriteLine($"Списано бонусов: {points}. Осталось: {BonusPoints}");
            }
            else
            {
                Console.WriteLine("Недостаточно бонусов.");
            }
        }
    }

    public class Order
    {
        private static int _nextOrderNumber = 1;

        public int Number { get; }
        public string Status { get; private set; }
        public DateTime OrderDateTime { get; }
        public decimal TotalAmount { get; private set; }
        public int ClientId { get; }
        public List<OrderItem> Items { get; }

        public Order(int number, int clientId)
        {
            Number = number;
            ClientId = clientId;
            Status = "Создан";
            OrderDateTime = DateTime.Now;
            Items = new List<OrderItem>();
            TotalAmount = 0;

            if (number >= _nextOrderNumber)
                _nextOrderNumber = number + 1;
        }

        public void AddItem(OrderItem item)
        {
            Items.Add(item);
            CalculateTotal();
            Console.WriteLine($"Добавлено блюдо: {item.Dish.Name} x{item.Quantity}");
        }

        public void RemoveItem(OrderItem item)
        {
            Items.Remove(item);
            CalculateTotal();
            Console.WriteLine($"Удалено блюдо: {item.Dish.Name}");
        }

        public void CalculateTotal()
        {
            TotalAmount = Items.Sum(item => item.CalculateCost());
        }

        public void ChangeStatus(string newStatus)
        {
            Status = newStatus;
            Console.WriteLine($"Статус заказа №{Number} изменен на: {newStatus}");
        }

        public void DisplayOrderInfo()
        {
            Console.WriteLine($"\n=== Заказ №{Number} ===");
            Console.WriteLine($"Статус: {Status}");
            Console.WriteLine($"Дата/время: {OrderDateTime}");
            Console.WriteLine($"ID клиента: {ClientId}");
            Console.WriteLine("Состав заказа:");

            foreach (var item in Items)
            {
                Console.WriteLine($"  - {item.Dish.Name} x{item.Quantity} = {item.CalculateCost()} руб.");
            }

            Console.WriteLine($"Итоговая сумма: {TotalAmount} руб.");
        }
    }

    
    public class OrderItem
    {
        public Dish Dish { get; set; }
        public int Quantity { get; set; }
        public string Comment { get; set; }

        public OrderItem(Dish dish, int quantity, string comment = "")
        {
            Dish = dish;
            Quantity = quantity;
            Comment = comment;
        }

        public decimal CalculateCost()
        {
            return Dish.Price * Quantity;
        }
    }

  
    public class Dish
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public bool IsAvailable { get; set; }

        public Dish(int id, string name, string category, decimal price, string description = "")
        {
            Id = id;
            Name = name;
            Category = category;
            Price = price;
            Description = description;
            IsAvailable = true;
        }

        public bool CheckAvailability()
        {
            return IsAvailable;
        }

        public void DisplayDishInfo()
        {
            string availability = IsAvailable ? "Да" : "Нет";
            Console.WriteLine($"{Name} - {Price} руб. ({Category}) Доступно: {availability}");
            if (!string.IsNullOrEmpty(Description))
                Console.WriteLine($"  Описание: {Description}");
        }
    }


    public class Menu
    {
        public List<Dish> Dishes { get; }

        public Menu()
        {
            Dishes = new List<Dish>();
        }

        public void AddDish(Dish dish)
        {
            Dishes.Add(dish);
            Console.WriteLine($"Блюдо '{dish.Name}' добавлено в меню.");
        }

        public void RemoveDish(int dishId)
        {
            var dish = Dishes.FirstOrDefault(d => d.Id == dishId);
            if (dish != null)
            {
                Dishes.Remove(dish);
                Console.WriteLine($"Блюдо '{dish.Name}' удалено из меню.");
            }
        }

        public List<Dish> FindDishesByCategory(string category)
        {
            return Dishes.Where(d => d.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public void UpdatePrice(int dishId, decimal newPrice)
        {
            var dish = Dishes.FirstOrDefault(d => d.Id == dishId);
            if (dish != null)
            {
                decimal oldPrice = dish.Price;
                dish.Price = newPrice;
                Console.WriteLine($"Цена блюда '{dish.Name}' изменена с {oldPrice} на {newPrice} руб.");
            }
        }

        public void DisplayMenu()
        {
            Console.WriteLine("\n МЕНЮ РЕСТОРАНА 'ЖАР-ПТИЦА'");
            var categories = Dishes.Select(d => d.Category).Distinct();

            foreach (var category in categories)
            {
                Console.WriteLine($"\n--- {category.ToUpper()} ---");
                var categoryDishes = FindDishesByCategory(category);
                foreach (var dish in categoryDishes)
                {
                    if (dish.IsAvailable)
                    {
                        dish.DisplayDishInfo();
                    }
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Menu restaurantMenu = new Menu();

            restaurantMenu.AddDish(new Dish(1, "Цезарь с курицей", "Салаты", 450, "Салат с курицей, сыром пармезан и соусом цезарь"));
            restaurantMenu.AddDish(new Dish(2, "Греческий салат", "Салаты", 380));
            restaurantMenu.AddDish(new Dish(3, "Бургер классический", "Бургеры", 320, "Говяжья котлета, сыр, салат, помидор"));
            restaurantMenu.AddDish(new Dish(4, "Чизбургер", "Бургеры", 350));
            restaurantMenu.AddDish(new Dish(5, "Картофель фри", "Гарниры", 150));
            restaurantMenu.AddDish(new Dish(6, "Кола", "Напитки", 120));
            restaurantMenu.AddDish(new Dish(7, "Апельсиновый сок", "Напитки", 180));

            Client client = new Client(1, "Каратеева Диана", "+79958375589", 123456);
            client.Register();
            client.Login();
            Console.WriteLine();

            restaurantMenu.DisplayMenu();
            Console.WriteLine();

            Order order = client.CreateOrder(1001);

            var caesarSalad = restaurantMenu.Dishes[0]; 
            var classicBurger = restaurantMenu.Dishes[2]; 
            var fries = restaurantMenu.Dishes[4]; 
            var cola = restaurantMenu.Dishes[5]; 

            order.AddItem(new OrderItem(caesarSalad, 1));
            order.AddItem(new OrderItem(classicBurger, 2, "Без лука"));
            order.AddItem(new OrderItem(fries, 1));
            order.AddItem(new OrderItem(cola, 2));

            order.CalculateTotal();
            order.ChangeStatus("Оплачен");

            order.DisplayOrderInfo();
            Console.WriteLine();

            client.PayOrder(order.TotalAmount);
            Console.WriteLine();

            order.ChangeStatus("Готовится");
            order.ChangeStatus("Готов к выдаче");
            Console.WriteLine();

            Console.WriteLine("\nВсе салаты в меню:");
            var salads = restaurantMenu.FindDishesByCategory("Салаты");
            foreach (var salad in salads)
            {
                salad.DisplayDishInfo();
            }

            restaurantMenu.UpdatePrice(1, 480); 
            Console.WriteLine();

           
            order.CalculateTotal();
            order.DisplayOrderInfo();
        }
    }
}